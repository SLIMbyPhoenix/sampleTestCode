package feature.slim;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.remote.Augmenter;

public class SlimClass {
	private static WebDriver driver;
	public static enum locaterTypeEnum {classname,css,id,linktext,name,partiallinktext,tagname,xpath};
	
	public SlimClass (WebDriver webdriver){
		driver = webdriver;
	}
	
	public static By getLocatorByEnum (locaterTypeEnum locaterType, String locatorValue){
		switch(locaterType)
		{
		case classname:
			return By.className(locatorValue);
		case css:
			return By.cssSelector(locatorValue);
		case id:
			return By.id(locatorValue);
		case linktext:
			return By.linkText(locatorValue);
		case name:
			return By.name(locatorValue);
		case partiallinktext:
			return By.partialLinkText(locatorValue);
		case tagname:
			return By.tagName(locatorValue);
		case xpath:
			return By.xpath(locatorValue);
		default:
			return null;
		}
}
	
	public static By getLocator (String locatorType, String locatorValue) throws Exception{
		if(locatorType.toLowerCase().equals("classname"))
			return By.className(locatorValue);
		else
			if (locatorType.toLowerCase().equals("css"))
			return By.cssSelector(locatorValue);
		else
			if (locatorType.toLowerCase().equals("id"))
			return By.id(locatorValue);
		else
			if (locatorType.toLowerCase().equals("linktext"))
			return By.linkText(locatorValue);
		else
			if (locatorType.toLowerCase().equals("name"))
			return By.name(locatorValue);
		else
			if (locatorType.toLowerCase().equals("partiallinktext"))
			return By.partialLinkText(locatorValue);
		else
			if (locatorType.toLowerCase().equals("tagname"))
			return By.tagName(locatorValue);
		else
			if (locatorType.toLowerCase().equals("xpath"))
			return By.xpath(locatorValue);
		else
			throw new Exception("Locator type '" + locatorType + "' not defined!!" + "\n" + "Having locator value '" + locatorValue + "'");
	}

	public static String captureScreenShot (String dirPath, String fileNameWithExt){
		/*String location = System.getProperty("user.dir") + "\\" + dirPath + "\\" +  fileNameWithExt;*/
		String location = dirPath + "\\" +  fileNameWithExt;
				
		try {
			//String base64 = ((TakesScreenshot)driver).getScreenshotAs(OutputType.BASE64);
			File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(scrFile, new File(location));
		} catch (IOException e) {
			location = "Failed to capture screenshot: " + e.getMessage();
			e.printStackTrace();
		}
		return location;
	}
	
	public static String captureScreenShot (String dirPathWithfileNameWithExt){
		/*String location = System.getProperty("user.dir") + "\\" + dirPathWithfileNameWithExt;*/
		String location = dirPathWithfileNameWithExt;
				
		try {
			//String base64 = ((TakesScreenshot)driver).getScreenshotAs(OutputType.BASE64);
			File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(scrFile, new File(location));
		} catch (IOException e) {
			location = "Failed to capture screenshot: " + e.getMessage();
			e.printStackTrace();
		}
		return location;
	}
	
	public static String captureRemoteDriverScreenShot (String dirPath, String fileNameWithExt) {
		/*String location = System.getProperty("user.dir") + "\\" + dirPathWithfileNameWithExt;*/
		String location = dirPath + "\\" +  fileNameWithExt;
		WebDriver agumentdriver = new Augmenter().augment(driver);
		
		try {
			//String base64 = ((TakesScreenshot)driver).getScreenshotAs(OutputType.BASE64);
			File scrFile = ((TakesScreenshot)agumentdriver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(scrFile, new File(location));
		} catch (IOException e) {
			location = "Failed to capture screenshot: " + e.getMessage();
			e.printStackTrace();
		}
		return location;
	}

	public static String captureRemoteDriverScreenShot (String dirPathWithfileNameWithExt) {
		/*String location = System.getProperty("user.dir") + "\\" + dirPathWithfileNameWithExt;*/
		String location = dirPathWithfileNameWithExt;
		WebDriver agumentdriver = new Augmenter().augment(driver);
		
		try {
			//String base64 = ((TakesScreenshot)driver).getScreenshotAs(OutputType.BASE64);
			File scrFile = ((TakesScreenshot)agumentdriver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(scrFile, new File(location));
		} catch (IOException e) {
			location = "Failed to capture screenshot: " + e.getMessage();
			e.printStackTrace();
		}
		return location;
	}
	
	public void injectjQueryIfNeeded(){
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		if(!jQueryLoaded(jse)) injectjQuery(jse);
	}
	
	private static Boolean jQueryLoaded(JavascriptExecutor driver){
		Boolean loaded;
		
		try {
			loaded = (Boolean) driver.executeScript("return jQuery()!=null");
		} catch (WebDriverException e) {
			loaded = false;
		}
		
		return loaded;
	}
	
	private static void injectjQuery(JavascriptExecutor driver){
		driver.executeScript(" var headID = document.getElementByTagName(\"head\")[0];"
				+ "var newScript = document.createElement('script');"
				+ "newScript.src = 'http://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js';"
				+ "headID.appendChild(newScript);");
	}
	
}
