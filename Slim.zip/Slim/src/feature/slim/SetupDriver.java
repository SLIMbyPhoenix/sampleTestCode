package feature.slim;

import feature.filehandling.PropertyFile;

import java.io.File;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.safari.SafariDriver;
import org.openqa.selenium.safari.SafariOptions;
import org.openqa.selenium.support.events.EventFiringWebDriver;


public class SetupDriver {
	public static enum browserTypeEnum {InternetExplorer,FireFox,Chrome,Safari};
	private browserTypeEnum browserType = null;
	private WebDriver webDriver = null;
	private EventFiringWebDriver efwd = null;
	private SeleniumListeners sl = null;
	//**********this needs to be moved to some constructor for implicit load***********************************
	public static PropertyFile config = new PropertyFile(System.getProperty("user.dir") + "\\Config\\config.properties");
	//*********************************************************************************************************

	public SetupDriver(browserTypeEnum browserName){
		browserType = browserName;
		try{
			//Switch Case to set up desired browser
			switch(browserType)
			{
			case InternetExplorer:
				webDriver = getIEDriverInstance();
				webDriver.manage().deleteAllCookies();
				webDriver.manage().window().maximize();
				break;
			case FireFox:
				webDriver = getFFDriverInstance();
				webDriver.manage().deleteAllCookies();
				webDriver.manage().window().maximize();
				break;
			case Chrome:
				webDriver = getChromeDriverInstance();
				webDriver.manage().deleteAllCookies();
				webDriver.manage().window().maximize();
				break;
			case Safari:
				webDriver = getSafariDriverInstance();
				webDriver.manage().deleteAllCookies();
				webDriver.manage().window().maximize();
				break;
			default:
				webDriver = new FirefoxDriver();
			}
			
			Thread.sleep(10000);
			efwd = new EventFiringWebDriver(webDriver);
			sl = new SeleniumListeners();
			efwd.register(sl);
		}
		catch(Exception e){
			//Log the message in the log file
			System.out.println(e.getMessage());
		}
	}
	
	
	
	
	public WebDriver getWebDriver() {
		return webDriver;
	}
	
	/*public void setWebDriver(WebDriver webDriver) {
		SetupDriver.webDriver = webDriver;
	}*/
	
	public browserTypeEnum getBrowserType() {
		return browserType;
	}
	
	/*public void setBrowserType(browserTypeEnum browserType) {
		SetupDriver.browserType = browserType;
	}*/
	
	public EventFiringWebDriver getEfwd() {
		return efwd;
	}
	
	/*public void setEfwd(EventFiringWebDriver efwd) {
		this.efwd = efwd;
	}*/
	
	public SeleniumListeners getSl() {
		return sl;
	}
	
	/*public void setSl(SeleniumListeners sl) {
		this.sl = sl;
	}*/
	
	private static WebDriver getIEDriverInstance(){
		// setting system property for IE browser
		File file = new File(System.getProperty("user.dir") + "\\Lib\\IEDriverServer.exe");
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		DesiredCapabilities ieCapabilities = DesiredCapabilities.internetExplorer();		
		ieCapabilities.setCapability("unexpectedAlertBehaviour" , "ignore");
		// Add this desiredcapabilities when the security level of IE not set to same.
		ieCapabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS,true);
		ieCapabilities.setBrowserName("SELENIUM");
		ieCapabilities.setJavascriptEnabled(true);
		ieCapabilities.setCapability("browserstack.ie.enablePopups", "true");
		ieCapabilities.setCapability("acceptSslCerts", "true");
		// ieCapabilities.setCapability("browserstack.ie.noFlash", "true");
		//ieCapabilities.setCapability("enablePersistentHover", true);
		
		return new InternetExplorerDriver(ieCapabilities);
		
		// create IE instance and maximize it
		//WebDriver ieDriver = new InternetExplorerDriver(ieCapabilities);
		//ieDriver.manage().window().maximize();
		//return ieDriver;

	}
	
	private static WebDriver getFFDriverInstance(){
		//FirefoxProfile profile = new FirefoxProfile();		
		//profile.setPreference("network.automatic-ntlm-auth.trusted-uris", "masteknet.com");//for https
		//return new FirefoxDriver(profile);
		
		//Creating new Firefox profile
		FirefoxProfile profile = new FirefoxProfile();
		profile.setAcceptUntrustedCertificates(true); 
		profile.setAssumeUntrustedCertificateIssuer(false);
		
		// create Mozill Firefox instance and maximize it
		WebDriver fireFoxDriver = new FirefoxDriver();
		fireFoxDriver.manage().window().maximize();
		return fireFoxDriver;
	}
	
	private static WebDriver getChromeDriverInstance(){
		DesiredCapabilities capability = DesiredCapabilities.chrome();
		// To Accept SSL certificate
		capability.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
		
		// setting system property for Chrome browser
		File file = new File(config.getPropValue("IEDriverServer")); //System.getProperty("user.dir") + "\\Lib\\chromedriver.exe"
		System.setProperty("webdriver.chrome.driver",file.getAbsolutePath());
		
		// create Google Chrome instance and maximize it
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--ignore-certificate-errors");
		options.addArguments("--disable-popup-blocking");
		options.addArguments("--disable-translate");
		options.addArguments("--start-maximized");
		return new ChromeDriver(options);
				
		// create Google Chrome instance and maximize it
		//WebDriver chromeDriver = new ChromeDriver(capability);
		//chromeDriver.manage().window().maximize();
		//return chromeDriver;
	}
	
	private static WebDriver getSafariDriverInstance(){
		SafariOptions safariOptions = new SafariOptions(); 
		safariOptions.setUseCleanSession(true);		
		return new SafariDriver(safariOptions);
	}

	public void TeardownDriver(){
		
		if (browserType!= null) browserType = null;
		if (webDriver != null) {webDriver.quit(); webDriver = null;}
		if (efwd != null) efwd = null;
		if (sl != null) sl = null;
	}


}
