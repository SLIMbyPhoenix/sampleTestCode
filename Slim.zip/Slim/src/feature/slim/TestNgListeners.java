package feature.slim;

import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;
import org.testng.TestListenerAdapter;

public class TestNgListeners extends TestListenerAdapter implements ITestListener{
	{
	 super.getPassedTests();
	 super.getFailedTests();
	 super.getSkippedTests();
	}
	
	//Testng Listener implementations start
		@Override
		public void onFinish(ITestContext arg0) {
			
			
		}

		@Override
		public void onStart(ITestContext arg0) {
			
			
		}

		@Override
		public void onTestFailedButWithinSuccessPercentage(ITestResult arg0) {
			
			
		}

		@Override
		public void onTestFailure(ITestResult arg0) {
			
			
		}

		@Override
		public void onTestSkipped(ITestResult arg0) {
			
			
		}

		@Override
		public void onTestStart(ITestResult arg0) {
			
			
		}

		@Override
		public void onTestSuccess(ITestResult arg0) {
			
			
		}
	//Testng Listener implementations end
}
