package feature.filehandling;

//https://www.seleniumeasy.com/selenium-tutorials/how-to-extract-pdf-text-and-verify-using-selenium-webdriver-java

public class PdfFile {

}
