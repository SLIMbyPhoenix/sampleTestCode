package feature.filehandling;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;

import javax.activation.MimetypesFileTypeMap;

import org.apache.tika.Tika;
import org.apache.tika.detect.TypeDetector;
import org.apache.tika.mime.MimeTypes;

public class FilesUtil {

	//http://marxsoftware.blogspot.com/2015/02/determining-file-types-in-java.html
	/** 
	 * Identify file type of file with provided path and name 
	 * using JDK 7's Files.probeContentType(Path). 
	 * 
	 * @param fileName Name of file whose type is desired. 
	 * @return String representing identified type of file with provided name. 
	 */  
	public String identifyFileTypeUsingFilesProbeContentType(final String fileName)  
	{  
	   String fileType = "Undetermined";  
	   final File file = new File(fileName);  
	   try  
	   {  
	      fileType = Files.probeContentType(file.toPath());  
	   }  
	   catch (IOException ioException)  
	   {  
	      System.out.println(
	    		  "ERROR: Unable to determine file type for " + fileName  
	              + " due to exception " + ioException);  
	   }
	   return fileType;  
	}
	
	//https://tika.apache.org/
	/** 
	 * Identify file type of file with provided name using 
	 * JDK 6's MimetypesFileTypeMap. 
	 * 
	 * See Javadoc documentation for MimetypesFileTypeMap class 
	 * (http://docs.oracle.com/javase/8/docs/api/javax/activation/MimetypesFileTypeMap.html) 
	 * for details on how to configure mapping of file types or extensions. 
	 */  
	public String identifyFileTypeUsingMimetypesFileTypeMap(final String fileName)  
	{      
	   final MimetypesFileTypeMap fileTypeMap = new MimetypesFileTypeMap();  
	   return fileTypeMap.getContentType(fileName);  
	}
	
	/** Instance of Tika facade class with default configuration. */  
	private final Tika defaultTika = new Tika();  
	  
	/** Instance of Tika facade class with MimeTypes detector. */  
	private final Tika mimeTika = new Tika(new MimeTypes());  
	   
	/** Instance of Tika facade class with Type detector. */  
	private final Tika typeTika = new Tika(new TypeDetector());
	
	/** 
	 * Identify file type of file with provided name using 
	 * Tika's default configuration. 
	 * 
	 * @param fileName Name of file for which file type is desired. 
	 * @return Type of file for which file name was provided. 
	 */  
	public String identifyFileTypeUsingDefaultTika(final String fileName)  
	{  
	   return defaultTika.detect(fileName);  
	}  
	  
	/** 
	 * Identify file type of file with provided name using 
	 * Tika's with a MimeTypes detector. 
	 * 
	 * @param fileName Name of file for which file type is desired. 
	 * @return Type of file for which file name was provided. 
	 */  
	public String identifyFileTypeUsingMimeTypesTika(final String fileName)  
	{  
	   return mimeTika.detect(fileName);  
	}  
	  
	/** 
	 * Identify file type of file with provided name using 
	 * Tika's with a Types detector. 
	 * 
	 * @param fileName Name of file for which file type is desired. 
	 * @return Type of file for which file name was provided. 
	 */  
	public String identifyFileTypeUsingTypeDetectorTika(final String fileName)  
	{  
	   return typeTika.detect(fileName);  
	}
	
	/** 
	 * Identify file type of file with provided name using 
	 * Tika's default configuration. 
	 * 
	 * @param fileName Name of file for which file type is desired. 
	 * @return Type of file for which file name was provided. 
	 */  
	public String identifyFileTypeUsingDefaultTikaForFile(final String fileName)  
	{  
	   String fileType;  
	   try  
	   {  
	      final File file = new File(fileName);  
	      fileType = defaultTika.detect(file);  
	   }  
	   catch (IOException ioEx)  
	   {  
	      System.out.println("Unable to detect type of file " + fileName + " - " + ioEx);  
	      fileType = "Unknown";  
	   }  
	   return fileType;  
	}  
	  
	/** 
	 * Identify file type of file with provided name using 
	 * Tika's with a MimeTypes detector. 
	 * 
	 * @param fileName Name of file for which file type is desired. 
	 * @return Type of file for which file name was provided. 
	 */  
	public String identifyFileTypeUsingMimeTypesTikaForFile(final String fileName)  
	{  
	   String fileType;  
	   try  
	   {  
	      final File file = new File(fileName);  
	      fileType = mimeTika.detect(file);  
	   }  
	   catch (IOException ioEx)  
	   {  
	      System.out.println("Unable to detect type of file " + fileName + " - " + ioEx);  
	      fileType = "Unknown";  
	   }  
	   return fileType;  
	}  
	  
	/** 
	 * Identify file type of file with provided name using 
	 * Tika's with a Types detector. 
	 * 
	 * @param fileName Name of file for which file type is desired. 
	 * @return Type of file for which file name was provided. 
	 */  
	public String identifyFileTypeUsingTypeDetectorTikaForFile(final String fileName)  
	{  
	   String fileType;  
	   try  
	   {  
	      final File file = new File(fileName);  
	      fileType = typeTika.detect(file);  
	   }  
	   catch (IOException ioEx)  
	   {  
	      System.out.println("Unable to detect type of file " + fileName + " - " + ioEx);  
	      fileType = "Unknown";  
	   }  
	   return fileType;  
	}
}
