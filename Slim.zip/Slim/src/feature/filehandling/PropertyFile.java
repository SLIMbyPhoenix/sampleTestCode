package feature.filehandling;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class PropertyFile {
	//Creating properties object
	private Properties prop = new Properties();
	   
	public PropertyFile(String filepath)  {
		   //Creating the File Object
		   File file = new File(filepath);
		   
		  //Creating InputStream object to read data
		   FileInputStream objInput = null;
		   
		   try {
		    objInput = new FileInputStream(file);
		    
		    //Reading properties key/values in file
		    prop.load(objInput);
		    
		    //Closing the InputStream
		    objInput.close();
		    
		    } catch (FileNotFoundException e) {
		    	System.out.println(e.getMessage());   
		     
		    } catch (IOException e) {
		    	System.out.println(e.getMessage());
		  }
	}
	
	public Properties getPropObject(){
		return prop;
	}
	
	public String getPropValue(String propKey){
		String propValue = prop.getProperty(propKey);
		return propValue;
	}
	
	public String[] getPropValues(String propKey){
		String propValue = prop.getProperty(propKey);
		String[] propValues = propValue.split("�");
		return propValues;
	}
}