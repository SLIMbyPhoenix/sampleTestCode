package feature.filehandling;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

import org.apache.poi.hssf.usermodel.HSSFFormulaEvaluator;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.ss.usermodel.Row;

public class ExcelFile {
	
	private static POIFSFileSystem newPOIfs = null;
	private static InputStream inputStreem = null;
	private HSSFWorkbook workBook = null;
	private HSSFSheet workSheet = null;

	public ExcelFile () {
		//FileOutputStream fileOutputStreem1 = null;
		//FileOutputStream fileOutputStreem2 = null;
	}

	public static boolean checkFileExist(String filePath) {
		if (filePath != "") {
			File newFile= new File(filePath);
			if (newFile.exists() && !newFile.isDirectory() && newFile.isFile()) {
				return true;
			} else {
				return false;
			}
		} else {
			return false;
		}
	}
	
	public static boolean setInputStream (String filePath) {
		if (checkFileExist(filePath)) {
			try {
				inputStreem = new FileInputStream(filePath);
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
			return setPOIfs ();
		} else {
			System.out.println("File: " + filePath + " checkFileExist(filePath) returned false");
			return false;
		}
	}
	
	public static InputStream getInputStream () {
		return inputStreem;
	}
	
	private static boolean setPOIfs () {
		try {
			newPOIfs = new POIFSFileSystem(inputStreem);
			return true;
		} catch (IOException e) {
			e.printStackTrace();
			return false;
		}
	}
	
	public static POIFSFileSystem getPOIfs () {
		return newPOIfs;
	}
	
	public ExcelFile setWorkBook () throws IOException {
		workBook = new HSSFWorkbook(newPOIfs);
		return this;
	}
	
	public HSSFWorkbook getWorkBook () {
		return workBook;
	}

	public ExcelFile setWorkSheet(String SheetName) {
		workSheet = workBook.getSheet(SheetName);
		return this;
	}
	
	public HSSFSheet getWorkSheet() {
		return workSheet;
	}
	
	public int getUsedRows() {
		return workSheet.getLastRowNum();
	}
	
	public int getUsedColumns() {
		int lastColNum = 0;
		int lastRowNum = getUsedRows();
		for(int x = 0; x <= lastRowNum; x++) {
			Row r = workSheet.getRow(x);
			int maxCell=  r.getLastCellNum();
			if (maxCell > lastColNum) {
				lastColNum = maxCell;
			}
		}
		return lastColNum;
	}
	
	public String getCellData (int rowNum, int colnum) {
		HSSFFormulaEvaluator.evaluateAllFormulaCells(workBook);
		
		
		return cellData;
	}
	
}
