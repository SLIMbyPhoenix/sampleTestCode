package feature.filehandling;

public class TextFile {

}
