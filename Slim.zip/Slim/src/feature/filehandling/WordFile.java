package feature.filehandling;

public class WordFile {

}
