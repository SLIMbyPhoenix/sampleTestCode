package feature.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

public class JdbcConnAndDml {
	// JDBC driver name and database URL
	   static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";  
	   static final String DB_URL = "jdbc:mysql://localhost:3306/test";

	   //  Database credentials
	   static final String USER = "root";
	   static final String PASS = "root";
	   /*
	   public static void main(String[] args) {
		   performDmlOperation("Update new_table Set new_tablecol = 'test3' where idnew_table = 3");
	   }*/
	   
	   public static void performDmlOperation(String queryStringValue) { //
		   Connection conn = null;
		   Statement stmt = null;
		   
		   try{
		      //STEP 2: Register JDBC driver
		      Class.forName("com.mysql.jdbc.Driver");
		      
		      //STEP 3: Open a connection
		      System.out.println("Connecting to a selected database...");
		      conn = DriverManager.getConnection(DB_URL, USER, PASS);
		      System.out.println("Connected database successfully...");
		      
		      //STEP 4: Execute a query
		      System.out.println("Creating statement...");
		      stmt = conn.createStatement();
		      String sql = queryStringValue;
		      //count will give you how many records got updated
		      int count = stmt.executeUpdate(sql);
		      System.out.println("Number of rows Updated: "+count);
		      
		      // Now you can extract all the records
		      // to see the updated records
		      
		      sql = "SELECT * FROM " + sql.substring(sql.toLowerCase().indexOf(" "),sql.toLowerCase().indexOf("set")) ;
		      ResultSet rs = stmt.executeQuery(sql);
		      
		      ResultSetMetaData resultSetMetaData = rs.getMetaData();
		      int columnCount = resultSetMetaData.getColumnCount();
		      
		      while(rs.next()){
		    	  String temp = null;
		         //Retrieve all by columns
		    	  for (int i = 1; i <= columnCount; i++) {
		    		  temp = temp + "	|	" + rs.getString(i);	//rs.getObject(i);
		    		  //https://da2i.univ-lille1.fr/doc/tutorial-java/jdbc/basics/retrieving.html
		    		  //Note that although the method getString() is recommended for retrieving the SQL types CHAR and VARCHAR,
		    		  //it is possible to retrieve any of the basic SQL types with it.
		    		  //You cannot, however, retrieve the new SQL3 datatypes with it.
		    	    }

		         //Display values
		         System.out.println("Row: " + temp);
		      }
		      rs.close();
		   }catch(SQLException se){
		      //Handle errors for JDBC
		      se.printStackTrace();
		   }catch(Exception e){
		      //Handle errors for Class.forName
		      e.printStackTrace();
		   }finally{
		      //finally block used to close resources
		      try{
		         if(stmt!=null)
		            conn.close();
		      }catch(SQLException se){
		      }// do nothing
		      try{
		         if(conn!=null)
		            conn.close();
		      }catch(SQLException se){
		         se.printStackTrace();
		      }//end finally try
		   }//end try
	   
		   System.out.println("JDBCConnectionDML.performDmlOperation("+ queryStringValue +") completed!");
	   }//end performDmlOperation
	   
	  /* 
	   public static void performUpdateOperation(String queryStringValue) {
	         
	        Connection con = null;
	        Statement stmt = null;
	        try {
	            Class.forName("oracle.jdbc.driver.OracleDriver");
	            con = DriverManager.getConnection("jdbc:oracle:thin:@<hostname>:<port num>:<DB name>","user","password");
	            stmt = con.createStatement();
	            String query = queryStringValue;
	            //count will give you how many records got updated
	            int count = stmt.executeUpdate(query);
	            System.out.println("Updated queries: "+count);
	        } catch (ClassNotFoundException e) {
	            // TODO Auto-generated catch block
	            e.printStackTrace();
	        } catch (SQLException e) {
	            // TODO Auto-generated catch block
	            e.printStackTrace();
	        } finally{
	            try{
	                if(stmt != null) stmt.close();
	                if(con != null) con.close();
	            } catch(Exception ex){}
	        }
	    }
	   */
}
