package layer.platform;

import org.openqa.selenium.os.WindowsUtils;

import feature.slim.SetupDriver.browserTypeEnum;

public class WindowOS {
	
	public static void killBrowserinstance(browserTypeEnum browseType){
		
		switch(browseType)
		{
		case InternetExplorer:
			WindowsUtils.tryToKillByName("iexplore.exe");
			break;
		case FireFox:
			WindowsUtils.tryToKillByName("firefox.exe");
			break;
		case Chrome:
			WindowsUtils.tryToKillByName("chrome.exe");
			break;
		default:
			break;
		}
		
	}
	
	public static String readRegStrValue(String regKey){
		
		String regValue = null;
		try {
			regValue = WindowsUtils.readStringRegistryValue(regKey);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
		return regValue;
	}
	
	public static int readRegIntValue(String regKey){
		
		int regValue = 0;
		try {
			regValue = WindowsUtils.readIntRegistryValue(regKey);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
		return regValue;
	}
	
	public static boolean readRegBolValue(String regKey){
		
		boolean regValue = false;
		try {
			regValue = WindowsUtils.readBooleanRegistryValue(regKey);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return regValue;
	}

	private void sample() {
		//WindowsUtils.regVersion1;
		//WindowsUtils.deleteRegistryValue(key);
		//WindowsUtils.discoverRegistryKeyType(key);
		//WindowsUtils.doesRegistryValueExist(key);
		WindowsUtils.findReg();
		WindowsUtils.findSystemRoot();
		WindowsUtils.findTaskKill();
		WindowsUtils.findWBEM();
		WindowsUtils.findWMIC();
		//WindowsUtils.getEnvVarIgnoreCase(var);
		WindowsUtils.getLocalAppDataPath();
		//WindowsUtils.getPathsInProgramFiles(childPath);
		WindowsUtils.getProgramFiles86Path();
		WindowsUtils.getProgramFilesPath();
		WindowsUtils.isRegExeVersion1();
		//WindowsUtils.kill(cmdarray);
		//WindowsUtils.killByName(name);
		//WindowsUtils.killPID(processID);
		WindowsUtils.loadEnvironment();
		//WindowsUtils.main(args);
		//WindowsUtils.procMap();
		//WindowsUtils.readBooleanRegistryValue(key);
		//WindowsUtils.readIntRegistryValue(key);
		//WindowsUtils.readStringRegistryValue(key);
		WindowsUtils.thisIsWindows();
		//WindowsUtils.traceWith(log);
		//WindowsUtils.tryToKillByName(name);
		//WindowsUtils.writeBooleanRegistryValue(key, data);
		//WindowsUtils.writeIntRegistryValue(key, data);
		//WindowsUtils.writeStringRegistryValue(key, data);
		
	}
	
}
