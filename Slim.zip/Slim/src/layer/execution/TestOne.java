package layer.execution;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import feature.filehandling.PropertyFile;
import feature.slim.*;
import feature.slim.SetupDriver.browserTypeEnum;
import feature.slim.SlimClass.locaterTypeEnum;


public class TestOne {
	public static WebDriver driver;

	public static void main(String[] args) {
		SetupDriver objSetupDriver = new SetupDriver(browserTypeEnum.FireFox);
		driver = objSetupDriver.getEfwd();
		//**********this needs to be moved to some constructor for implicit load***********************************
		//PropertyFile config = new PropertyFile(System.getProperty("user.dir") + "\\Config\\config.properties");
		//*********************************************************************************************************
		String filePath1 = SetupDriver.config.getPropValue("ObjectMap");
		String filePath2 = SetupDriver.config.getPropValue("OR_Sample");
		
		PropertyFile testData01 = new PropertyFile(System.getProperty("user.dir") + filePath2);
		String urlValue = testData01.getPropValue("ECX.FRMA.URL");
		
		PropertyFile testData = new PropertyFile(System.getProperty("user.dir") + filePath1);
		String[] typeValue = testData.getPropValues("ECX.LoginPage.txtUserName");
		
		By txtUserName = null;
		try {
			txtUserName = SlimClass.getLocator(typeValue[0].toString(), typeValue[1].toString());
			//txtUserName = SlimClass.getLocatorByEnum(locaterTypeEnum.valueOf(typeValue[0].toString()), typeValue[1].toString());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//---------------------------------------
		//driver.findElement(arg0);
		//driver.findElements(arg0);
		driver.getClass();
		//---------------------------------------
		driver.close();
		//driver.equals(obj);
		driver.get(urlValue);
		driver.getCurrentUrl();
		driver.getPageSource();
		driver.getTitle();
		driver.getWindowHandle();
		driver.getWindowHandles();
		//driver.manage().addCookie(cookie);
		driver.manage().deleteAllCookies();
		//driver.manage().deleteCookie(cookie);
		//driver.manage().deleteCookieNamed(name);
		//driver.manage().
		//driver.manage().timeouts().implicitlyWait(time, unit);
		//driver.manage().timeouts().
		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		driver.manage().timeouts().setScriptTimeout(30, TimeUnit.SECONDS);
		//driver.manage().timeouts().
		
		//driver.manage().getCookieNamed(name);
		driver.manage().getCookies();
		driver.manage().window().getPosition();
		driver.manage().window().getSize();
		driver.manage().window().maximize();
		//driver.manage().window().setPosition(targetPosition);
		//driver.manage().window().setSize(targetSize);
		driver.navigate().back();
		driver.navigate().forward();
		driver.navigate().refresh();
		//driver.navigate().to(String);
		//driver.navigate().to(URL);
		driver.quit();
		driver.switchTo().activeElement();
		driver.switchTo().alert();
		driver.switchTo().defaultContent();
		//driver.switchTo().frame(index);
		//driver.switchTo().frame(nameOrId);
		//driver.switchTo().frame(frameElement);
		//driver.switchTo().parentFrame();
		//driver.switchTo().window(nameOrHandle);
		//---------------------------------------
		driver.hashCode();
		driver.notify();
		driver.notifyAll();
		driver.toString();
		//driver.wait();
		//driver.wait(timeout);
		//driver.wait(timeout, nanos);
		//---------------------------------------
		
		WebElement elementHandle = driver.findElement(txtUserName);
		//---------------------------------------
		//elementHandle.findElement(arg0);
		//elementHandle.findElements(arg0);
		elementHandle.getClass();
		//---------------------------------------
		elementHandle.clear();
		elementHandle.click();
		//elementHandle.equals(obj);
		//elementHandle.getAttribute(arg0);
		//elementHandle.getCssValue(arg0);
		elementHandle.getLocation();
		//elementHandle.getScreenshotAs(arg0);
		elementHandle.getSize();
		elementHandle.getTagName();
		elementHandle.getText();
		elementHandle.isDisplayed();
		elementHandle.isEnabled();
		elementHandle.isSelected();
		//elementHandle.sendKeys(arg0);
		elementHandle.submit();
		//---------------------------------------
		elementHandle.hashCode();
		elementHandle.notify();
		elementHandle.notifyAll();
		elementHandle.toString();
		//elementHandle.wait();
		//elementHandle.wait(timeout);
		//elementHandle.wait(timeout, nanos);
		//---------------------------------------
		
		
		WebDriverException exceptionFound = new WebDriverException();
		//exceptionFound.addInfo(key, value);
		//exceptionFound.addSuppressed(exception);
		//exceptionFound.equals(obj);
		exceptionFound.fillInStackTrace();
		exceptionFound.getAdditionalInformation();
		exceptionFound.getBuildInformation();
		exceptionFound.getCause();
		exceptionFound.getClass();
		exceptionFound.getLocalizedMessage();
		exceptionFound.getMessage();
		exceptionFound.getStackTrace();
		exceptionFound.getSupportUrl();
		exceptionFound.getSuppressed();
		exceptionFound.getSystemInformation();
		exceptionFound.hashCode();
		//exceptionFound.initCause(cause);
		exceptionFound.notify();
		exceptionFound.notifyAll();
		exceptionFound.printStackTrace();
		//exceptionFound.printStackTrace(s);
		//exceptionFound.printStackTrace(s);
		//exceptionFound.setStackTrace(stackTrace);
		exceptionFound.toString();
		//exceptionFound.wait();
		//exceptionFound.wait(timeout);
		//WebDriverException.DRIVER_INFO;
		//WebDriverException.SESSION_ID;
		//exceptionFound.getDriverName(stackTraceElements);
		
		Actions builder = new Actions (driver);
		//builder. ... .build().perform();
		builder.click();
		//builder.click(onElement);
		builder.clickAndHold();
		//builder.clickAndHold(onElement);
		builder.contextClick();
		//builder.contextClick(onElement);
		builder.doubleClick();
		//builder.doubleClick(onElement);
		//builder.dragAndDrop(source, target);
		//builder.dragAndDropBy(source, xOffset, yOffset);
		//builder.keyDown(theKey);
		//builder.keyDown(element, theKey);
		//builder.keyUp(theKey);
		//builder.keyUp(element, theKey);
		//builder.moveByOffset(xOffset, yOffset);
		//builder.moveToElement(toElement);
		//builder.moveToElement(toElement, xOffset, yOffset);
		builder.perform();
		builder.release();
		//builder.release(onElement);
		//builder.sendKeys(keysToSend);
		//builder.sendKeys(element, keysToSend);
		
		
		
		Select select = new Select(elementHandle);
		select.deselectAll();
		//select.deselectByIndex(index);
		//select.deselectByValue(value);
		//select.deselectByVisibleText(text);
		select.getAllSelectedOptions();
		select.getFirstSelectedOption();
		select.getOptions();
		select.isMultiple();
		//select.selectByIndex(index);
		//select.selectByValue(value);
		//select.selectByVisibleText(text);
		
	}
}
